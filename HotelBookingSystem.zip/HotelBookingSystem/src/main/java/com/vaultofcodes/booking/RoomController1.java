package com.vaultofcodes.booking;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RoomController1")
public class RoomController1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>Hotel Booking System</title></head><body>");
        out.println("<h1>Hotel Booking System</h1>");

        // Display available rooms
        out.println("<h2>Available Rooms</h2>");
        for (int i = 1; i <= 20; i++) {
            out.println("Room " + i + "<br>");
        }

        // Booking form
        out.println("<h2>Book a Room</h2>");
        out.println("<form action='" + request.getContextPath() + "/RoomController1' method='post'>");
        out.println("Room Number: <input type='number' name='roomNumber' required><br>");
        out.println("<input type='submit' value='Book Room'>");
        out.println("</form>");

        out.println("</body></html>");
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 String roomNumber = request.getParameter("roomNumber");
	        response.setContentType("text/html");
	        PrintWriter out = response.getWriter();

	        out.println("<html><head><title>Booking Confirmation</title></head><body>");
	        out.println("<h1>Booking Confirmation</h1>");
	        out.println("<p>You have successfully booked Room " + roomNumber + ".</p>");
	        out.println("</body></html>");
	}

}
